var censor = require("censorify");
console.log(censor.getCensoredWords());
console.log(censor.censor("Bardzo smutny, nieodobry i szalony tekst."));
censor.addCenWord("ponury");
console.log(censor.getCensoredWords());
console.log(censor.censor("Bardzo ponury las."));
