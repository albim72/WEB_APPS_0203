export enum TodoStatus {
  TODO,
  IN_PROGRESS,
  IN_REVIEW,
  BUG,
  DONE
}
