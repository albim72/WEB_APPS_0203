import { Component, DoCheck } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css','./bootstrap-4.4.1.css']
})
export class AppComponent implements DoCheck{
  heading = 'Przed kliknięciem...';
  list: string[] = [];
  doCheckFires = 0;
  counter=0;

  ngDoCheck(): void {
    ++this.doCheckFires;
  }

  click():void {
    this.counter++;
    this.heading = 'Po kliknięciu...';
    this.list = ['Ważna opcja nr 88','Bardzo istotna kwestia...','Trzecia rzecz!',
      'Kolejny temat...','Kaluzula specjalna...']
  }
}
